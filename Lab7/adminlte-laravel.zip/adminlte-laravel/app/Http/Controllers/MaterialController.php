<?php

namespace App\Http\Controllers;

use App\Models\Material;
use App\Models\Category;
use App\Models\Author;
use Illuminate\Http\Request;

class MaterialController extends Controller
{
    public function index()
    {
        $materials = Material::with(['category', 'author'])->latest()->get();
        return view('materials.index', compact('materials'));
    }

    public function create()
    {
        $categories = Category::all();
        $authors = Author::all();
        return view('materials.create', compact('categories', 'authors'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|max:255',
            'content' => 'required',
            'category_id' => 'required|exists:categories,id',
            'author_id' => 'required|exists:authors,id',
        ]);

        Material::create($validated);
        return redirect()->route('materials.index')->with('success', 'Material created successfully');
    }
    
    public function popularCategories()
    {
        $categories = Category::withCount('materials')
            ->orderByDesc('views_count')
            ->get();
        $totalViews = $categories->sum('views_count');

        return view('reports.popular_categories', compact('categories', 'totalViews'));
    }

    public function edit(Material $material)
    {
        $categories = Category::all();
        $authors = Author::all();
        return view('materials.edit', compact('material', 'categories', 'authors'));
    }

    public function update(Request $request, Material $material)
    {
        $validated = $request->validate([
            'title' => 'required|max:255',
            'content' => 'required',
            'category_id' => 'required|exists:categories,id',
            'author_id' => 'required|exists:authors,id',
        ]);

        $material->update($validated);
        return redirect()->route('materials.index')
            ->with('success', 'Material updated successfully');
    }

    public function show(Material $material)
    {
        // Increment the material views
        $material->increment('views');
        
        // Increment the category views_count
        $material->category()->increment('views_count');
        
        // Load relationships if not already loaded
        $material->load(['category', 'author']);
        
        return view('materials.show', compact('material'));
    }
    
    public function destroy(Material $material)
    {
        try {
            $material->delete();
            return redirect()->route('materials.index')
                ->with('success', 'Material deleted successfully');
        } catch (\Exception $e) {
            return redirect()->route('materials.index')
                ->with('error', 'Error deleting material: ' . $e->getMessage());
        }
    }
}