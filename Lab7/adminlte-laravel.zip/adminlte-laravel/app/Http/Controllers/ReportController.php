<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function popularCategories()
    {
        $categories = Category::withCount('materials')
            ->withSum('materials', 'views')
            ->orderByDesc('views_count')
            ->get();

        $totalViews = $categories->sum('views_count');

        return view('reports.popular_categories', compact('categories', 'totalViews'));
    }
}