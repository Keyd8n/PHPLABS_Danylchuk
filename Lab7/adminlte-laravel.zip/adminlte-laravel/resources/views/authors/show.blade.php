
@extends('adminlte::page')

@section('title', 'Author Details')

@section('content_header')
    <h1>
        Author Details
        <a href="{{ route('authors.edit', $author) }}" class="btn btn-warning float-right">
            <i class="fas fa-edit"></i> Edit Author
        </a>
    </h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="info-box">
                        <span class="info-box-icon bg-info"><i class="fas fa-user"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Name</span>
                            <span class="info-box-number">{{ $author->name }}</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="info-box">
                        <span class="info-box-icon bg-success"><i class="fas fa-envelope"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Email</span>
                            <span class="info-box-number">{{ $author->email ?: 'Not provided' }}</span>
                        </div>
                    </div>
                </div>
            </div>

            @if($author->materials->count() > 0)
                <div class="card mt-4">
                    <div class="card-header">
                        <h3 class="card-title">Materials by this Author</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            @foreach($author->materials as $material)
                                <li class="list-group-item">
                                    {{ $material->title }}
                                    <span class="float-right">
                                        <i class="fas fa-eye"></i> {{ $material->views }}
                                    </span>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            @endif
        </div>
    </div>

    <div class="mt-3">
        <a href="{{ route('authors.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Authors
        </a>
    </div>
@stop