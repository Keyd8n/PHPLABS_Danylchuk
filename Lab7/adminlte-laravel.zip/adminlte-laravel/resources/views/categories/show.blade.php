
@extends('adminlte::page')

@section('title', 'Category Details')

@section('content_header')
    <h1>
        Category Details
        <a href="{{ route('categories.edit', $category) }}" class="btn btn-warning float-right">
            <i class="fas fa-edit"></i> Edit Category
        </a>
    </h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="info-box">
                        <span class="info-box-icon bg-info"><i class="fas fa-folder"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Name</span>
                            <span class="info-box-number">{{ $category->name }}</span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="info-box">
                        <span class="info-box-icon bg-success"><i class="fas fa-book"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Materials Count</span>
                            <span class="info-box-number">{{ $category->materials_count }}</span>
                        </div>
                    </div>
                </div>
            </div>

         

            @if($category->materials->count() > 0)
                <div class="card mt-4">
                    <div class="card-header">
                        <h3 class="card-title">Materials in this Category</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            @foreach($category->materials as $material)
                                <li class="list-group-item">
                                    {{ $material->title }}
                                    <span class="float-right">
                                        <i class="fas fa-eye"></i> {{ $material->views }}
                                    </span>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            @endif
        </div>
    </div>

    <div class="mt-3">
        <a href="{{ route('categories.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Categories
        </a>
    </div>
@stop