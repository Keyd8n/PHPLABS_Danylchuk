@extends('adminlte::page')

@section('title', $material->title)

@section('content_header')
    <h1>
        {{ $material->title }}
        <small class="text-muted">
            <i class="fas fa-eye"></i> {{ number_format($material->views) }} views
        </small>
    </h1>
@stop

@section('content')
    <div class="card">
        <div class="card-header">
            <div class="float-right">
                <a href="{{ route('materials.edit', $material) }}" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Edit
                </a>
                <a href="{{ route('materials.index') }}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-8">
                    <div class="form-group">
                        <label>Content</label>
                        <div class="p-3 bg-light">
                            {!! nl2br(e($material->content)) !!}
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="info-box">
                        <span class="info-box-icon bg-info"><i class="fas fa-tag"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Category</span>
                            <span class="info-box-number">{{ $material->category->name }}</span>
                        </div>
                    </div>
                    <div class="info-box">
                        <span class="info-box-icon bg-success"><i class="fas fa-user"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Author</span>
                            <span class="info-box-number">{{ $material->author->name }}</span>
                        </div>
                    </div>
                    <div class="info-box">
                        <span class="info-box-icon bg-warning"><i class="fas fa-calendar"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Created</span>
                            <span class="info-box-number">{{ $material->created_at->format('d.m.Y H:i') }}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop