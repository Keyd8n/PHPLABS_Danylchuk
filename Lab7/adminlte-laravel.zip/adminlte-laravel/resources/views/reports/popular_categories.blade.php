@extends('adminlte::page')

@section('title', 'Popular Categories Report')

@section('content_header')
    <h1>Popular Categories Report</h1>
@stop

@section('content')
    <div class="card">
        <div class="card-body">
            <div class="row">
                @foreach($categories as $category)
                    <div class="col-md-4">
                        <div class="info-box">
                            <span class="info-box-icon bg-info"><i class="fas fa-book"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text">{{ $category->name }}</span>
                                <span class="info-box-number">
                                    {{ $category->materials_count }} materials
                                </span>
                                <div class="text-muted">
                                    {{ $category->materials_sum_views ?? 0 }} views
                                    @if($totalViews > 0)
                                        ({{ number_format((($category->materials_sum_views ?? 0) / $totalViews) * 100, 1) }}%)
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <div class="row mt-4">
                <div class="col-12">
                    <div class="card bg-gradient-info">
                        <div class="card-header border-0">
                            <h3 class="card-title">Total Statistics</h3>
                        </div>
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h5>Total Categories: {{ $categories->count() }}</h5>
                                </div>
                                <div>
                                    <h5>Total Materials: {{ $categories->sum('materials_count') }}</h5>
                                </div>
                                <div>
                                    <h5>Total Views: {{ $totalViews }}</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop

@section('css')
    <style>
        .info-box {
            min-height: 100px;
            margin-bottom: 20px;
        }
    </style>
@stop