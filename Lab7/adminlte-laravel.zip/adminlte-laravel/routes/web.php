<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\MaterialController;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\AuthorController;

// Dashboard route
Route::get('/', function () {
    return view('welcome');
});

// Materials routes
Route::resource('materials', MaterialController::class);

// Reports routes
Route::get('/reports/popular-categories', [ReportController::class, 'popularCategories'])
    ->name('reports.popular-categories');

// Categories routes
Route::resource('categories', CategoryController::class);

// Authors routes
Route::resource('authors', AuthorController::class);
