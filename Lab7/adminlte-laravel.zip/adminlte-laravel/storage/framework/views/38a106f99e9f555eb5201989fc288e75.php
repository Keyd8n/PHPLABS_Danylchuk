

<?php $__env->startSection('title', $material->title); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>
        <?php echo e($material->title); ?>

        <small class="text-muted">
            <i class="fas fa-eye"></i> <?php echo e(number_format($material->views)); ?> views
        </small>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <div class="float-right">
                <a href="<?php echo e(route('materials.edit', $material)); ?>" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Edit
                </a>
                <a href="<?php echo e(route('materials.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-8">
                    <div class="form-group">
                        <label>Content</label>
                        <div class="p-3 bg-light">
                            <?php echo nl2br(e($material->content)); ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="info-box">
                        <span class="info-box-icon bg-info"><i class="fas fa-tag"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Category</span>
                            <span class="info-box-number"><?php echo e($material->category->name); ?></span>
                        </div>
                    </div>
                    <div class="info-box">
                        <span class="info-box-icon bg-success"><i class="fas fa-user"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Author</span>
                            <span class="info-box-number"><?php echo e($material->author->name); ?></span>
                        </div>
                    </div>
                    <div class="info-box">
                        <span class="info-box-icon bg-warning"><i class="fas fa-calendar"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Created</span>
                            <span class="info-box-number"><?php echo e($material->created_at->format('d.m.Y H:i')); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\adminlte-project\adminlte-laravel\resources\views/materials/show.blade.php ENDPATH**/ ?>