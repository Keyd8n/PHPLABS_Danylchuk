

<?php $__env->startSection('title', 'Popular Categories Report'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Popular Categories Report</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="info-box">
                            <span class="info-box-icon bg-info"><i class="fas fa-book"></i></span>
                            <div class="info-box-content">
                                <span class="info-box-text"><?php echo e($category->name); ?></span>
                                <span class="info-box-number">
                                    <?php echo e($category->materials_count); ?> materials
                                </span>
                                <div class="text-muted">
                                    <?php echo e($category->materials_sum_views ?? 0); ?> views
                                    <?php if($totalViews > 0): ?>
                                        (<?php echo e(number_format((($category->materials_sum_views ?? 0) / $totalViews) * 100, 1)); ?>%)
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row mt-4">
                <div class="col-12">
                    <div class="card bg-gradient-info">
                        <div class="card-header border-0">
                            <h3 class="card-title">Total Statistics</h3>
                        </div>
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h5>Total Categories: <?php echo e($categories->count()); ?></h5>
                                </div>
                                <div>
                                    <h5>Total Materials: <?php echo e($categories->sum('materials_count')); ?></h5>
                                </div>
                                <div>
                                    <h5>Total Views: <?php echo e($totalViews); ?></h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .info-box {
            min-height: 100px;
            margin-bottom: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\adminlte-project\adminlte-laravel\resources\views/reports/popular_categories.blade.php ENDPATH**/ ?>