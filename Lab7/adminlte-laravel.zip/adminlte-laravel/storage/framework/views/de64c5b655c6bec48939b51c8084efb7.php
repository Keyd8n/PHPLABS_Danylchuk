


<?php $__env->startSection('title', 'Category Details'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>
        Category Details
        <a href="<?php echo e(route('categories.edit', $category)); ?>" class="btn btn-warning float-right">
            <i class="fas fa-edit"></i> Edit Category
        </a>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="info-box">
                        <span class="info-box-icon bg-info"><i class="fas fa-folder"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Name</span>
                            <span class="info-box-number"><?php echo e($category->name); ?></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="info-box">
                        <span class="info-box-icon bg-success"><i class="fas fa-book"></i></span>
                        <div class="info-box-content">
                            <span class="info-box-text">Materials Count</span>
                            <span class="info-box-number"><?php echo e($category->materials_count); ?></span>
                        </div>
                    </div>
                </div>
            </div>

         

            <?php if($category->materials->count() > 0): ?>
                <div class="card mt-4">
                    <div class="card-header">
                        <h3 class="card-title">Materials in this Category</h3>
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            <?php $__currentLoopData = $category->materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="list-group-item">
                                    <?php echo e($material->title); ?>

                                    <span class="float-right">
                                        <i class="fas fa-eye"></i> <?php echo e($material->views); ?>

                                    </span>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="mt-3">
        <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-secondary">
            <i class="fas fa-arrow-left"></i> Back to Categories
        </a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\adminlte-project\adminlte-laravel\resources\views/categories/show.blade.php ENDPATH**/ ?>